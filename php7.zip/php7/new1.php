<?php
	/*class House{
		public function add($a){
			return $a;
		}
	}
	$obj = new House();
	echo $obj->add('Durgapur');*/
class Tv{
	public $volume;
	public $model;
	function volumeUp(){
		return $this->volume+=1;
	}
	function volumeDown(){
		return $this->volume-=1;
	}
	function __construct($a,$b){
		$this->volume=$a;
		$this->model=$b;
	}
}
class Next extends Tv{
	public $vol;
	public $mod;
	function __construct($x,$y){
		$this->vol=$x;
		$this->mod=$y;
	}
}
$obj3 = new Next(4, 'XYZ');
echo $obj3->vol;
echo $obj3->mod;
$obj2 = new Next("yut", 9);
echo $obj2->vol;
echo $obj2->mod;

?>