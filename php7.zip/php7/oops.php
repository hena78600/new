<?php
/*In OOPS Programming Language we follow a design philosophy that uses objects and methods rather than linear concepts of procedures and tasks to accomplish programatic rules
ANd Object is the self sustainable construct that enables reusability of codes A METHOD specifies one operation without providing any details to describe how the operation should be carried on ------------- 
Advantage : 1. Modularity:- It reverse to the concept of making multiple modules first and then linking and combining them to form a complete system. It enables reusability and minmizes duplications
2. Reusability:- Code can be reused without modification 
3. Information/Data Id:- INTERNAL iMPLEMENTation OF A MODULE (class) remailns hidden from the outside world.
4.Debugging :- Its is easier bcoz the module (class) is independent from other pieces of code 
Fundamentals :) 1:- Class:- Its a collection of variables and functions working with this variables. Its a template from which object is created.
Properties:) Class member variables are called properties.(Attributes/Fields).
Properties and methods visibility:)- 1:- Private Visibility:- This type allows access to members of the same class. Can we access only by the class that defines the member.
Protected Visibility :- ALlows access to members of the same class and instances from classes that inherit from that one class
Public Visibility:- Refers to a property or method that is accessible from anywhere
Object : Instance of Class It refers to a particular instance of a class where object can be a combination of variables, functions, and data structure. 

.*/
/*class A{
	public $a;   //Data Member/ Member Variable
	public $b;
	function add($a,$b){     //Member Function
		return $a+$b;
	}
}
$obj = new A;
$obj ->add(5,6);*/

//class A{
	/*public $a;   //Data Member/ Member Variable
	public $b;*/
	/*function add($a,$b){     //Member Function
		return $a+$b;
	}
	function sub($a,$b){     //Member Function
		return $a-$b;
	}
}
$obj = new A;
echo $obj ->add(5,6);

$obj1 = new A;
echo $obj1 ->sub(10,5);*/




/*class Tv{
	public $volume;
	public $model;
	function volumeUp(){
		return $this->volume+=1;
	}
	function volumeDown(){
		return $this->volume-=1;
	}
	function __construct(){
		$this->volume=3;
		$this->model='abcd';
	}
}
$obj = new Tv;
echo $obj ->volume;
echo "<br>";
echo $obj ->model;
echo $obj->volumeUp();
echo $obj->volumeDown();
*/

class Tv{
	public $volume;
	public $model;
	function volumeUp(){
		return $this->volume+=1;
	}
	function volumeDown(){
		return $this->volume-=1;
	}
	function __construct($a,$b){
		$this->volume=$a;
		$this->model=$b;
	}
}
/*$obj = new Tv(3,'abcd');
echo $obj ->volume;
echo $obj ->model;
echo $obj->volumeUp();
echo $obj->volumeDown();*/

class Next extends Tv{
	public $vol;
	public $mod;
	function __construct($x,$y){
		$this->vol=$x;
		$this->mod=$y;
	}
}
$obj3 = new Next(4, 'XYZ');
echo $obj3->vol;
echo $obj3->mod;
$obj2 = new Next("yut", 9);
echo $obj2->vol;
echo $obj2->mod;












?>