<?php 
/*Encapsulation : It is concerned with the hiding the implementation details and only exposing the methods
Purpose:1) it reduces software development complexity by hiding the implementation details and exposing the operations 
2)Protects the internal state of an object.-Access to the class variable by get set method that makes class flexible and easy to maintain.

*/
/*class Animal{
	private $food;
	private $family;
	public function __construct($food,$family){
		$this->food=$food;
		$this->family=$family;
	}
	public function getFamily(){
		return $this->family;
	}
	public function setFamily($family){
		return $this->family=$family;
	}
	public function getFood(){
		return $this->food;
	}
	public function setFood($food){
		return $this->food=$food;
	}
}
class H extends Animal{
	private $owner;
	public function __construct($family,$food){
		parent::__construct($family, $food);
	}
	public function getOwner(){
		return $this->owner;
	}
	public function setOwner($owner){
		return $this->owner=$owner;
	}
}
class C extends Animal{
	public function __construct($family,$food){
		parent::__construct($family, $food);
	}
}
$obj1 = new H('Herbivorus','Grass');
echo $obj1->getFamily().'<br>';
echo $obj1->getFood().'<br>';


$obj2 = new C('Herbi','Ani');
echo $obj2->getFamily().'<br>';
echo $obj2->getFood();

$obj3 = new H('Tiger','df');
echo $obj3->getOwner().'<br>';*/


	/* add() addition of 2 no
	sub class extends Base class
	sub() 2nos substraction
	nested class extends sub
	multiple()
	2nos multiplication
	4. class show extends nested it should have a constructor
	parent+scope resolution operator cal to add method sub method and multiple method.
	object will be of show class
	*/
/*	class Base{
		public function add(){
			$a = 10;
			$b = 12;
			$c = $a + $b;
			echo $c.'<br>';
		}
}
class Sub extends Base{
		public function sub(){
			$a = 10;
			$b = 12;
			$c = $a - $b;
			echo $c.'<br>';
		}
}
class nested extends sub{
		public function multiple(){
			$a = 10;
			$b = 12;
			$c = $a * $b;
			echo $c;
		}
}
class show extends nested{
		public function __construct(){
			parent:: add();
			parent:: sub();
			parent::multiple();
		}
}
$obj1 = new show();*/

/*Final Keyword : Final Methods prevents method overriding, final classes prevents inheritence. */

  /*class A{
 	 public function show($x,$y){
 		$z = $x+$y;
 		echo $z;
 	}
 }
 class B extends A{
 	final public function show($x,$y){
 		$z = $x*$y;
 		echo $z;
 	}
 }
$obj1 = new B();
$obj1->show(5,10);*/

/*Abstract class are classes in which atleast one method is abstract (declared using abstract keyword) Use:----- All the base classes implementing this class should give implementation of the abstract methods declared in the parent class. Abstract class can contain abstract as well as non abstract method.*/

/*abstract class A{
	abstract function show();
}
class B extends A{
	function show(){
		echo "string";
	}
}
$obj1 = new B;
$obj1->show();*/

/*abstract class car{
	protected $tankvolume;
	public function settankvolume($volume){
		$this->tankvolume=$volume;
	}
	abstract public function calcTankVolume();
}
class Newcar extends car{
	function calcTankVolume(){
		$miles = $this->tankvolume * 30;
		return $miles;
	}
}
class T extends car{
	public function calcTankVolume(){
		$miles = $this->tankvolume * 33;
		return $miles;
	}
	public function color(){
		return 'blue';
	}
}
$obj1 = new T;
echo $obj1->settankvolume(2);
echo $obj1->calcTankVolume();
echo $obj1->color();*/

/*Php Variables:--Global keyword is used to access a global variable from within a function  */
/*$x = 5;
$y = 10;
 function variables(){
 	global $x, $y;
 	$z = $x+$y;
 	echo $z;
 }
variables();
echo $y;*/

/*Php also stores all global variables in an array called $GLOBAL['']   . The index holds the name of the variable ths array is also accessible from within functions and can also be used to update global variables directly. */

/*$x = 5;
$y = 10;
 function variables(){
 	$GLOBALS['y'] = $GLOBALS['x']+ $GLOBALS['y'];
 	echo $GLOBALS['y'].'<br>';

 }
variables();
echo $y;*/

function teststatic(){
	static $x=0;
	echo $x;
	$x++;
}
teststatic();
teststatic();
teststatic();
















?>
