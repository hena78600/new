<?php
		//error_reporting(0);
		/*declare(strict_types = 1);
		function sum(float $a,float $b){
			echo $a+$b;
			
		}*/
		/*Coersive type*/
		/*sum(4,"8");
		sum(4,"8 days1");
		sum(4.1, 6.8);*/
		/*sum(4.5,5.7);
		sum(5,7);
		sum(5, "2 days");*/

		/*Return Type Declaration*/
		/*function add($a, $b):float{
			return $a+$b;
		}
		var_dump(add(1.7,2.3));*/

		/*declare(strict_types = 1);
		function add($a, $b):int{
			return $a+$b;
		}
		var_dump(add(1,'2days'));
		var_dump(add(1.2,3.5));*/

		/*$a = 3;
		echo($a%2 == 0)? "Even No" : "Odd Number";*/        /*Ternary Operator ------------- (have left to right)*/
		//echo $a;

		/*$num1 = 10;
		print($num1)??"NULL"; *//*NULL COALESCING OPERATOR -------------------- (have right to left)*/

		/*Space Shift Operator ------------ (It is used to compare two expressions and return -1, 0, 1 When one variable is less than , equal to or greater than as compare to other variable.)*/

		/*echo 1<=>1;
		echo 1<=>2;
		echo 2<=>1;*/

/*Constant Array using Define ---------()*/
		/*define('Name', array('ABCD', "XYZ"));
		echo Name[1];*/


/*Closer Call ---------------(is a way to temporarily bind an object scope to a closer and invoke it...it takes object as the first argument followed by any arguments to pass into the closer)     -------------(bindTo Function of PHP 5)    */
		/*class Math{
			private $val = 100;
		}
		$getval = function(){
			return $this->val*2;
		};
		$value = $getval->call(new Math);
		print("The Value is:");
		print($value);*/

/*Remove Extension AND SAPI's e.g mssql, mysql, sybase_ct  In PHP & two methods are introduced to generate cryptograpically secured integers and strings */

/*random_bytes() Method
random_int()

*/
		/*$a = random_bytes(2);
		print(bin2hex($a));*/

		//$a = random_int(2);
		/*$a = random_int(30, 100);
		echo $a;*/
		

?>