<?php include('header.php'); ?>
<section>
    <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
        <img src="img/background2.jpg" class="d-block w-100" alt="...">
    </div>
</section>
<section class="search-sec">
    <div class="container">
        <form action="#" method="post" novalidate="novalidate">
            <div class="flight-tab row">
                              <div class="persent-one">
                                 <i class="fa fa-map-marker" aria-hidden="true"></i>
                                 <input type="text" name="dep" class="textboxstyle" id="dep" placeholder="From City or airport">
                              </div>
                              <div class="persent-one">
                                 <i class="fa fa-map-marker" aria-hidden="true"></i>
                                 <input type="text" name="dep" class="textboxstyle" id="arival" placeholder="To City or airport">
                              </div>
                              <div class="persent-one less-per">
                                 <i class="fa fa-calendar" aria-hidden="true"></i>
                                 <input type="text" name="dep" class="textboxstyle" id="from-date1" placeholder="Depart">
                              </div>
                              <div class="persent-one less-per">
                                 <i class="fa fa-calendar" aria-hidden="true"></i>
                                 <input type="text" name="dep" class="textboxstyle" id="to-date" placeholder="Returrn">
                              </div>
                              <div class="persent-one">
                                 <i class="fa fa-user" aria-hidden="true"></i>
								 <input type="text" name="dep" class="textboxstyle" id="user" placeholder=" No. of Travellers">
                                 
								 
                              </div>
                              <div class="persent-one less-btn">
                                 <input type="Submit" name="submit" value="Search" class="btn btn-info cst-btn" id="srch">
                              </div>
                           </div>
        </form>
    </div>
</section>
<section class="yatra-special-section">



</section>



<?php include('footer.php') ?>