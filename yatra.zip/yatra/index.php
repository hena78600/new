<?php include('header.php'); 
?>
<section>
    <div id="carouselExampleFade" class="carousel slide carousel-fade" data-ride="carousel">
        <img src="img/background2.jpg" class="d-block w-100" alt="...">
    </div>
</section>
<section class="search-sec">
    <div class="container">
        <form action="search.php" method="GET">
            <div class="flight-tab row">
                              <div class="persent-one">
                                 <i class="fa fa-map-marker" aria-hidden="true"></i>
                                 <input type="text" name="dep" class="textboxstyle" id="dep" placeholder="From City or airport" autocomplete="off" required>
                                 <div id="dep_list"></div>
                              </div>
                              <div class="persent-one">
                                 <i class="fa fa-map-marker" aria-hidden="true"></i>
                                 <input type="text" name="arival" class="textboxstyle" id="arival" placeholder="To City or airport" autocomplete="off" required="">
                                 <div id="arival_list"></div>
                              </div>
                              <div class="persent-one less-per">
                                 <i class="fa fa-calendar" aria-hidden="true"></i>
                                 <input type="text" name="from-date1" class="textboxstyle" id="from-date1" placeholder="Depart" autocomplete="off" >
                              </div>
                              <div class="persent-one less-per">
                                 <i class="fa fa-calendar" aria-hidden="true"></i>
                                 <input type="text" name="to-date" class="textboxstyle" id="to-date" placeholder="Return" autocomplete="off" >
                              </div>
                              <div class="persent-one">
                                 <i class="fa fa-user" aria-hidden="true"></i>
								                 <input type="number" name="nooftraveller" class="textboxstyle" id="nooftraveller" placeholder="No. of Travellers" autocomplete="off" required="">
                              </div>
                              <div class="persent-one less-btn">
                                 <input type="Submit" name="submit" value="Search" class="btn btn-info cst-btn" >
                              </div>
                           </div>
        </form>
    </div>
</section>
<section class="yatra-special-section" style="padding-bottom: 40px;">
    <div class="container">
      <h2 style="text-align: center;">Domestic Flights</h2><br>
    <div class="row">
      <?php $sql = mysqli_query($con, "SELECT * FROM flight_details ORDER BY id DESC LIMIT 9");
             while($row = mysqli_fetch_assoc($sql)){
             ?>
      <div class="col-xs-4">
        <div class="offer offer-radius offer-primary">
          <div class="shape">
            <div class="shape-text">
              top               
            </div>
          </div>
          <div class="offer-content">
            <p class="lead">
             <p><?php echo $row['routes_from']; ?> to <?php echo $row['routes_to']; ?>
            </p>           
            <p>Flight</p>
              </p>
          </div>
        </div>
      </div>
    <?php } ?>
    </div>
    
</div>


</section>
<script>
    $(function() {
      $( "#from-date1" ).datepicker();
        });
    $(function() {
      $( "#to-date" ).datepicker();
        });

</script>
<script>
  $(document).ready(function(){  
      $('#dep').keyup(function(){  
           var query = $(this).val();  
           if(query != '')  
           {  
                $.ajax({  
                     url:"modules/find_city.php",  
                     method:"POST",  
                     data:{query:query},  
                     success:function(data)  
                     {  
                          $('#dep_list').fadeIn();  
                          $('#dep_list').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', '#find>li', function(){  
           $('#dep').val($(this).text()); 
           var container = $('#find'),
           scrollTo = $('#dep');
           container.animate({scrollTop: scrollTo.offset().top - container.offset().top + 
                       container.scrollTop()}); 
           $('#dep_list').fadeOut();  
      });  
 });  

   $(document).ready(function(){  
      $('#arival').keyup(function(){  
           var query = $(this).val();  
           //alert(query);
           if(query != '')  
           {  
                $.ajax({  
                     url:"modules/arival_city.php",  
                     method:"POST",  
                     data:{query:query},  
                     success:function(data)  
                     {  
                          $('#arival_list').fadeIn();  
                          $('#arival_list').html(data);  
                     }  
                });  
           }  
      });  
      $(document).on('click', '#arival_find>li', function(){  
           $('#arival').val($(this).text()); 
           var container = $('#arival_find'),
           scrollTo = $('#arival');
           container.animate({scrollTop: scrollTo.offset().top - container.offset().top + 
                       container.scrollTop()});  
           $('#arival_list').fadeOut();  
      }); 
 });  

  </script>

<?php include('footer.php'); ?>