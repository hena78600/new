<?php include('header.php');
include('function.php');
?>

<section class="login-form-sec">
<div class="container">
<div class="form-signup">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="img/download.png" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
    <form method="POST" id="signup-id" onsubmit="return validate();">
		<div class="col-sm-6">
		  <input type="text" id="inputName" class="form-control" name="inputName" placeholder="Full Name">
		</div>
		<div class="col-sm-6">
		  <input type="text" id="email" class="form-control" name="email" placeholder="Email Id">
		</div>
		<div class="col-sm-6">
			<input type="text" id="Inputphone" class="form-control" name="phone" placeholder="Phone Number">
		</div>
		<div class="col-sm-6">
			<input type="text" id="inputPass" class="form-control" name="password" placeholder="Passowrd">
		</div>
		
		  <input type="submit" name="submit" class="fadeIn fourth" value="Signup">
		  <div id="Result"></div>
    </form>
	
    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="login.php">Login</a>
    </div>

  </div>
</div>
</div>
</section>
<script>
	function validate(){
		// alert('hii');
		var flag = true;
			var name = $('#inputName').val().trim();
			if(name == ''){
				flag = false;
				$('#inputName').css("border-color", "red");
			}else{
				$('#inputName').css("border-color", "");
			}
			var email = $('#email').val().trim();
			var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
			if(email == '' || !re.test(String(email).toLowerCase())){
				flag = false;
				$('#email').css("border-color", "red");
			}else{
				$('#email').css("border-color", "");
			}
			var Inputphone = $('#Inputphone').val().trim();
                if (Inputphone == "" || isNaN(Inputphone) || Inputphone.length !=10){
                    flag = false;
                $('#Inputphone').css("border-color","red");
                } else {
                  $('#Inputphone').css("border-color","");
                }


			var pass = $('#inputPass').val().trim();
			var regularExpression = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;
			if(pass == '' || !regularExpression.test(pass) ){
				flag = false;
				$('#inputPass').css("border-color", "red");
			}else{
				$('#inputPass').css("border-color", "");
			}
			if (flag === false){
			return false;
		  }
			if(name != '' && email != '' && Inputphone != '' && pass != ''){
			var dataString = "name="+name+"&email="+email+"&Inputphone="+Inputphone+"&password="+pass;
			// alert(dataString);
			$.ajax({
            type: "POST",
            url: "modules/users.php",
            data: dataString,
            cache: false,
            success: function(result){
				if(result == 'success'){
                     $('#Result').html('<p class="text-info">Registered Successfully</p>');
					 $('#signup-id')[0].reset();
					//alert(result);
			}else{
				$('#Result').html('<p class="text-info">'+result+'</p>');
			}
			}
        });
			}
			return false;
	}
</script>

<?php include('footer.php') ?>