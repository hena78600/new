<?php include('header.php'); 
include ('sidebar.php'); 
include('function.php');
if(!isset($_SESSION['admin'])){
	location('location:index.php');
}
?>
<section class="flight-details-sec">
	<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Flight Details</h3>
					<div class="row">
						<div class="col-md-6">
							<!-- BASIC TABLE -->
							<div class="panel">
								<div class="panel-body">
									<form action="" method="POST">
									  <fieldset>
									    <div class="form-group">
									    	<div class="col-sm-12">
										      <label for="InputFname">Flight ID</label>
										      <input type="text" class="form-control" name="fid" id="InputFname" placeholder="Flight ID" required="">
									  		</div>
									    </div>
									    <div class="form-group">
									    	<div class="col-sm-12">
									      		<label for="froutes">Routes Available</label>
									 		</div>
									      	<div class="col-sm-6">
										      <select class="form-control" name="froutes" id="froutes" required="">
										      	<?php $sql = mysqli_query($con, "SELECT * FROM routes");
										      	?><option selected disabled>From</option>
										      	<?php while($row = mysqli_fetch_assoc($sql)){
										      	?>
										        <option><?php echo $row['routes_name']; ?></option>
										    	<?php } ?>
										      </select>
									  		</div>
									  		<div class="col-sm-6">
										      <select class="form-control" name="troutes" id="troutes" required="">
										      	<?php $sql = mysqli_query($con, "SELECT * FROM routes");
										      	?><option selected disabled>To</option>
										      	<?php while($row = mysqli_fetch_assoc($sql)){
										      	?>
										        <option><?php echo $row['routes_name']; ?></option>
										    	<?php } ?>
										      </select>
									  		</div>

									    </div>
									    <div class="form-group">
									    	<div class="col-sm-12">
									      		<label for="datepicker">Week days Availability</label>
									 		</div>
									      	<div class="col-sm-12">
									      		<input type="checkbox" name="favail[]" value="monday">Monday
									      		<input type="checkbox" name="favail[]" value="tuesday">Tuesday
									      		<input type="checkbox" name="favail[]" value="wednesday">Wednesday
									      		<input type="checkbox" name="favail[]" value="thursday">Thursday
									      		<input type="checkbox" name="favail[]" value="friday">Friday
									      		<input type="checkbox" name="favail[]" value="saturday">Saturday
									      		<input type="checkbox" name="favail[]" value="sunday">Sunday
									  		</div>
										  
									    </div> 
									    <div class="form-group">
									    	<div class="col-sm-12">
									      		<label for="time">Timing</label>
									 		</div>
									      	<div class="col-sm-6">
										      <input type="time" class="form-control" name="stime" id="time" placeholder="Starting time" required="">
									  		</div>
										  <div class="col-sm-6">
										      <input type="time" class="form-control" name="dtime" id="des_time" placeholder="Desination Time" required="">
										  </div>
									    </div>
									    <div class="form-group">
									    	<div class="col-sm-12">
										      <label for="seatsavail">Seats Availability</label>
										      <input type="number" class="form-control" name="seatsavail" id="seatsavail" placeholder="Seats Available" required="">
										  	</div>
									    </div>
									    <div class="form-group">
									    	<div class="col-sm-12">
										      <label for="seatsavail">Flight Fare</label>
										      <input type="number" class="form-control" name="f_fare" id="f_fare" placeholder="Flight Fare" required="">
										  	</div>
									    </div>
									    <div class="col-sm-12"><br>
									    </div>
									    <div class="form-group">
									    	<div class="col-sm-12">
										      <button type="submit" name="submit" class="btn btn-primary">Submit</button>
										  	</div>
									    </div>
									    </fieldset>
									</form>
									<?php
									if(isset($_POST['submit'])){
										$fid = $_POST['fid'];
										$froutes = $_POST['froutes'];
										$troutes = $_POST['troutes'];
										//echo $routes;
										$stime = $_POST['stime'];
										$dtime = $_POST['dtime'];
										$seatsavail = $_POST['seatsavail'];
										$f_fare = $_POST['f_fare'];
										$favail = implode(',',$_POST['favail']);
										/*echo "<pre>";
										print_r($_POST);
										echo "</pre>";*/
										if (!empty($favail)){

										$sel = mysqli_query($con, "SELECT * FROM flight_details WHERE fid = '$fid' AND routes_from = '$froutes' AND routes_to = '$troutes'" );
										if(mysqli_num_rows($sel) == 1){
											echo "Flight is already added";
										}else{
											$sql = mysqli_query($con, "INSERT INTO flight_details(fid, routes_from, routes_to, start_time, destination_time,  f_available, seats, f_fare) VALUES('$fid', '$froutes', '$troutes', '$stime', '$dtime', '$favail', '$seatsavail' , '$f_fare')");
											echo "Flight details added";
										}
									}
								}
									
									?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	
<?php include('footer.php'); ?>