<?php include('header.php'); 
include ('sidebar.php');
include('function.php');
?>
<!-- MAIN -->
		<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Booking Details</h3>
					<div class="row">
						<div class="col-md-8">
							<!-- BASIC TABLE -->
							<div class="panel">
								<div class="panel-heading">
									<h3 class="panel-title">List Of Booking</h3>
								</div>
								<div class="panel-body">
									<table class="table">
										<thead>
											<tr>
												<th>Traveller Name</th>
												<th>Age</th>
												<th>Flight Id</th>
												<th>Seats Number </th>
												<th>Price</th>
											</tr>
										</thead>
										<tbody>
											<?php $sql = mysqli_query($con, "SELECT * FROM seats") ;
											while($row = mysqli_fetch_assoc($sql)){
											?>
											<tr>
												<td><?php echo $row['user_name'] ?></td>
												<td><?php echo $row['age'] ?></td>
												<td><?php echo $row['flight_id'] ?></td>
												<td><?php echo $row['seats_no'] ?></td>
												<td><?php echo $row['price'] ?></td>
											</tr>
											<?php } ?>
										</tbody>
									</table>
								</div>
							</div>
							<!-- END BASIC TABLE -->
						</div>
						
				</div>
			</div>
			<!-- END MAIN CONTENT -->
		</div>
	</div>
	
<?php include('footer.php'); ?>