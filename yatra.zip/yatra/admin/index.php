<?php include('function.php'); ?>
<!doctype html>
<html lang="en" class="fullscreen-bg">

<head>
	<title>Login | Yatra - Online Flight Booking</title>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<!-- VENDOR CSS -->
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.min.css">
	<link rel="stylesheet" href="assets/vendor/linearicons/style.css">
	<!-- MAIN CSS -->
	<link rel="stylesheet" href="assets/css/main.css">
	<!-- FOR DEMO PURPOSES ONLY. You should remove this in your project -->
	<link rel="stylesheet" href="assets/css/demo.css">
	<!-- GOOGLE FONTS -->
	<link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" rel="stylesheet">
	<!-- ICONS -->
	<link rel="apple-touch-icon" sizes="76x76" href="assets/img/apple-icon.png">
	<link rel="icon" type="image/png" sizes="96x96" href="../img/download.png">
</head>

<body>
	<!-- WRAPPER -->
	<div id="wrapper">
		<div class="vertical-align-wrap">
			<div class="vertical-align-middle">
				<div class="auth-box ">
					<div class="left">
						<div class="content">
							<div class="header">
								<div class="logo text-center"><img src="../img/download.png" alt="Klorofil Logo"></div>
								<p class="lead">Login to your account</p>
							</div>
							<form class="form-auth-small" action="index.php" method="POST">
								<div class="form-group">
									<label for="signin-email" class="control-label sr-only">Email</label>
									<input type="email" class="form-control" name="signin-email" placeholder="Email">
								</div>
								<div class="form-group">
									<label for="signin-password" class="control-label sr-only">Password</label>
									<input type="password" class="form-control" name="signin-password" placeholder="Password">
								</div>
								<div class="form-group clearfix">
									<label class="fancy-checkbox element-left">
									<input type="checkbox" name="remember" value="1" id="remember" <?php if(isset($_COOKIE["member_login"])) { ?> checked <?php } ?> />
										
										<span>Remember me</span>
									</label>
								</div>
								<input type="submit" name="submit" class="btn btn-primary btn-lg btn-block" value="LOGIN">
								<div class="bottom">
									<span class="helper-text"><i class="fa fa-lock"></i> <a href="page-lockscreen.html">Forgot password?</a></span>
								</div>
							</form>
							<?php
							if(isset($_POST['submit'])){
								$email = $_POST['signin-email'];
								$pass = md5($_POST['signin-password']);
								// $remember = $_POST['remember'];
								$sql = mysqli_query($con, "SELECT * FROM admin WHERE email='$email' AND password = '$pass' ");
								if(mysqli_num_rows($sql) == 0){
									echo 'Invalid Email or Password'; 
								}else{
									if(!empty($_POST['remember'])){
										setcookie('email', $email, time()+ 86400*30,"yatra");
										setcookie('password', $_POST['signin-password'], time()+ 86400*30,"yatra");
										setcookie('remember', $_POST['remember'], time()+ 86400*30,"yatra");
										}
									else{
										setcookie('email', '');
										setcookie('pass', '');
										setcookie('RememberMe', '');
									}
									$fetch = mysqli_fetch_assoc($sql);
									$email = $fetch['email'];
									$_SESSION['admin'] = $email;
									header('location:profile.php');
								}
							}
							
							?>
						</div>
					</div>
					<div class="right">
						<div class="overlay"></div>
						<div class="content text">
							
						</div>
					</div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
	</div>
	<!-- END WRAPPER -->
</body>

</html>
