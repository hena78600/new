<?php include('header.php'); 
include ('sidebar.php'); 
include('function.php');
?>
<section class="flight-details-sec">
	<div class="main">
			<!-- MAIN CONTENT -->
			<div class="main-content">
				<div class="container-fluid">
					<h3 class="page-title">Domestic Routes in India</h3>
					<div class="row">
						<div class="col-md-6">
							<!-- BASIC TABLE -->
							<div class="panel">
								<div class="panel-body">
									<form action="" method="POST">
									  <fieldset>
									  	<div class="form-group">
									    	<div class="col-sm-12">
									      		<label for="exampleInputPassword1">Routes Available</label>
									 		</div>
									      	<div class="col-sm-8">
										      <input type="text" name="r_from" class="form-control" id="InputFname" placeholder="Routes Name" required="">
									  		</div>
									    </div>
									    <div class="col-sm-12"><br></div>
									     <div class="form-group">
									    	<div class="col-sm-12">
										      <button type="submit" name="submit" class="btn btn-primary">Submit</button>
										  	</div>
									    </div>
									  </fieldset>
									</form>
									<?php
									if(isset($_POST['submit'])){
										$from = $_POST['r_from'];
										$fetch = mysqli_query($con, "SELECT * FROM routes WHERE routes_name = '$from' ");
										if(mysqli_num_rows($fetch) == 1){
											echo "Routes already exist";
										}else{
										$sql = mysqli_query($con, "INSERT INTO routes (routes_name ) VALUES('$from')");
										echo "Routes added successfully";
									}
								}
									?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>


<?php include('footer.php'); ?>