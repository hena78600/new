<?php
include('../function.php');
if(isset($_POST["query"]))  
 {  
      $output = '';
      /*$sql = mysqli_query($con, "SELECT distinct routes.routes_from from routes WHERE routes.routes_from is not null
		UNION
		SELECT distinct routes.routes_to from routes WHERE routes.routes_to is not null");
		$row = mysqli_fetch_assoc($sql); 
		print_r($row['routes_from']); exit; */ 
        $query = "SELECT * FROM routes WHERE routes_name LIKE '%".$_POST["query"]."%'";  
      $result = mysqli_query($con, $query);  
      $output = '<ul id="arival_find" class="list-unstyled">';  
      if(mysqli_num_rows($result) > 0)  
      {  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '<li>'.$row["routes_name"].'</li>';  
           }  
      }  
      else  
      {  
           $output .= '<li style="pointer-events: none;">City Not Found</li>';  
      }  
      $output .= '</ul>';  
      echo $output;  
 }  
 ?>  