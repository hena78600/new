<?php
include('../function.php');
if(isset($_POST['name'], $_POST['email'] , $_POST['Inputphone'] , $_POST['password']) ){
	$name = $_POST['name'];
	$email = $_POST['email'];
	$phone = $_POST['Inputphone'];
	$pass = md5($_POST['password']);
	$check = mysqli_query($con, "SELECT * FROM users WHERE email = '$email'");
	$chk = mysqli_query($con, "SELECT * FROM users WHERE phone = '$phone'");
	if(mysqli_num_rows($check) == 1){
		echo 'Email already registered';
	}elseif(mysqli_num_rows($chk) == 1){
		echo 'Mobile Number already registered';
	}else{
	$sql = mysqli_query($con, "INSERT INTO users (name, email, phone, password) VALUES('$name', '$email', $phone, '$pass')");
	echo 'success';
	}
}
if(isset($_POST['username'], $_POST['pass'])){
	$username = $_POST['username'];
	$password = md5($_POST['pass']);
	 // echo '<pre>';
	 // print_r($_POST);
	 // echo '</pre>';
	$sql = mysqli_query($con, "SELECT * FROM users WHERE email = '$username' AND password = '$password'");
	if(mysqli_num_rows($sql) == 1){
		$fetch = mysqli_fetch_array($sql);
		$_SESSION['users'] = $fetch['email'];
		echo 'success';
		echo "<script>window.location.href='profile.php'; </script>";
	}else{
		echo 'Invalid Credential';
	}
	
}
?>