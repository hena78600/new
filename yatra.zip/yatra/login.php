<?php include('header.php'); ?>

<section class="login-form-sec">
<div class="container">
<div class="login_Form_sec">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="img/download.png" id="icon" alt="User Icon" />
    </div>

    <!-- Login Form -->
    <form method="POST" id="login_Form" onsubmit="return validate();">
      <input type="text" id="username" class="fadeIn second" name="login" placeholder="username">
      <input type="text" id="password" class="fadeIn third" name="login" placeholder="password">
      <input type="submit" class="fadeIn fourth" value="Login">
	  <div id="val_cred"></div>
    </form>

    <!-- Remind Passowrd -->
    <div id="formFooter">
      <a class="underlineHover" href="signup.php">Signup</a>
    </div>

  </div>
</div>
</div>
</section>

<script>
function validate(){
	var flag = true;
		var username = $('#username').val().trim();
		if(username == ''){
			flag = false;
			$('#username').css("border-color", "red");
		}else{
			$('#username').css("border-color", "");
		}
		var password = $('#password').val().trim();
		if(password == ''){
			flag = false;
			$('#password').css("border-color", "red");
		}else{
			$('#password').css("border-color", "");
		}
		if(flag === false){
			return false;
		}
		if(username != '' && password != ''){
			var dataString = "username="+username+"&pass="+password;
			//alert(dataString);
			$.ajax({
            type: 'POST',
            url: 'modules/users.php',
            data: dataString,
            cache: false,
            success: function(result){
				if(result === 'Success'){
                    window.location.href = 'profile.php';
                    }else{
                        $('#val_cred').html('<p class="text-danger">'+result+'</p>');
                    }
			}
        });
		}
		return false;
}
</script>



<?php include('footer.php') ?>