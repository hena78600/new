<?php
include('function.php');
if(isset($_SESSION['users'])) {
    $email = $_SESSION['users'];
    $chk = mysqli_query($con, "SELECT * FROM users WHERE email = '$email'");
    $fetch = mysqli_fetch_assoc($chk);
    //echo $email;
}
if(isset($_GET['id'])){
    $id = base64_decode($_GET['id']);
    //          $traveller = $_GET['nooftraveller']; exit;
    $sql = mysqli_query($con, "SELECT * FROM flight_details WHERE fid='$id'");
    $fetch = mysqli_fetch_assoc($sql);
    $nooftraveller = $_GET['nooftraveller'];
    echo $fetch['f_fare'];
}
?>
<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Flight Seat Selection</title>
    <!-- Meta-Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Movie Seat Selection a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
    <!-- <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script> -->
    <!-- //Meta-Tags -->
    <!-- Index-Page-CSS -->
    <link rel="stylesheet" href="css/style_book.css" type="text/css" media="all">
    <!-- //Custom-Stylesheet-Links -->
    <!--fonts -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> 
    <link rel="icon" type="image/png" sizes="96x96" href="img/download.png">
    <link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
    <!-- //fonts -->
</head>

<body onload="onLoaderFunc()">
    <section class="book-sec">
    <h1>Flight Seat Selection</h1>
    <div class="container">
        <?php
         $check = mysqli_query($con, "SELECT * FROM seats WHERE flight_id = '$id'");
            $seats = array();
          

         while($row = mysqli_fetch_array($check)){
            $inner_seats = explode(',',$row['seats_no'] );
            $len = count($inner_seats);
                for($k = 0; $k<$len; $k++){
                    $seats[] =  $inner_seats[$k];
                }


         }
           
        ?>
        <form id="BookingForm" method="POST">
        <div class="w3ls-reg">
            <!-- input fields -->
            <div class="inputForm">
                <h2>fill the required details below and select your seats.</h2>
                <?php $x = 1; 
                while($x <= $_GET['nooftraveller']) { ?>
                <div class="mr_agilemain">
                    <div class="agileits-left">
                        <label>Adults Name
                            <span>*</span>
                        </label>
                        <input type="text" name="Username[]" id="Username" required>
                        <input type="hidden" name="f_id" id="f_id" value="<?php echo $id; ?>">
                        <input type="hidden" name="amount" value="<?php echo $fetch['f_fare']; ?>">
                    </div>
                    <div class="agileits-right">
                        <label> Adult's Age
                            <span>*</span>
                        </label>
                        <input type="text" name="userage[]" id="userage" required min="1">
                    </div>
                </div>
            <?php $x++; } ?>
                
            </div>
            <!-- //input fields -->
            <!-- seat availabilty list -->
            <ul class="seat_w3ls">
                <li class="smallBox greenBox">Selected Seat</li>

                <li class="smallBox redBox">Reserved Seat</li>

                <li class="smallBox emptyBox">Empty Seat</li>
            </ul>
            <!-- seat availabilty list -->
            <!-- seat layout -->
            <div class="seatStructure txt-center" style="overflow-x:auto;">
                <table id="seatsBlock" onmouseup="runThis()">
                    <p id="notification"></p>
                    <tr>
                        <td></td>
                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                        <td></td>
                        <td>6</td>
                        <td>7</td>
                        <td>8</td>
                        <td>9</td>
                        <td>10</td>
                        <td>11</td>
                        <td>12</td>
                    </tr>
                    <tr>
                        <td>A</td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A1" <?php echo (in_array('A1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A2" <?php echo (in_array('A2', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A3" <?php echo (in_array('A3', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A4" <?php echo (in_array('A4', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A5" <?php echo (in_array('A5', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td class="seatGap"></td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A6" <?php echo (in_array('A6', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A7" <?php echo (in_array('A7', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A8" <?php echo (in_array('A8', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A9" <?php echo (in_array('A9', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A10" <?php echo (in_array('A10', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A11" <?php echo (in_array('A11', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="A12" <?php echo (in_array('A12', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                    </tr>

                    <tr>
                        <td>B</td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B1" <?php echo (in_array('B1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B2" <?php echo (in_array('B2', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B3" <?php echo (in_array('B3', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B4" <?php echo (in_array('B4', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B5" <?php echo (in_array('B5', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td></td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B6" <?php echo (in_array('B6', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B7" <?php echo (in_array('B7', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B8" <?php echo (in_array('B8', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B9" <?php echo (in_array('B9', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B10" <?php echo (in_array('B10', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B11" <?php echo (in_array('B11', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="B12" <?php echo (in_array('B12', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                    </tr>

                    <tr>
                        <td>C</td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="C1" <?php echo (in_array('C1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="C2" <?php echo (in_array('C2', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="C3" <?php echo (in_array('C3', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="C4" <?php echo (in_array('C4', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="C5" <?php echo (in_array('C5', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td></td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="C6" <?php echo (in_array('C6', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="C7" <?php echo (in_array('C7', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="C8" <?php echo (in_array('C8', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="C9" <?php echo (in_array('C9', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="C10" <?php echo (in_array('C10', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" class="sts[]" value="C11" <?php echo (in_array('C10', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="C12" <?php echo (in_array('C12', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                    </tr>

                    <tr>
                        <td>D</td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D1" <?php echo (in_array('D1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D2" <?php echo (in_array('D2', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D3" <?php echo (in_array('D3', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D4" <?php echo (in_array('D4', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D5" <?php echo (in_array('D5', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td></td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D6" <?php echo (in_array('D6', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D7" <?php echo (in_array('D7', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D8" <?php echo (in_array('D8', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D9" <?php echo (in_array('D9', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D10" <?php echo (in_array('D10', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D11" <?php echo (in_array('D11', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="D12" <?php echo (in_array('D12', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                    </tr>

                    <tr>
                        <td>E</td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E1" <?php echo (in_array('E1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E2" <?php echo (in_array('E2', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E3" <?php echo (in_array('E3', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E4" <?php echo (in_array('E4', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E5" <?php echo (in_array('E5', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td></td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E6" <?php echo (in_array('E6', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E7" <?php echo (in_array('E7', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E8" <?php echo (in_array('E8', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E9" <?php echo (in_array('E9', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E10" <?php echo (in_array('E10', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E11" <?php echo (in_array('E11', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="E12" <?php echo (in_array('E12', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                    </tr>

                    <tr class="seatVGap"></tr>

                    <tr>
                        <td>F</td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="F1" <?php echo (in_array('F1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="F2" <?php echo (in_array('F2', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="F3" <?php echo (in_array('F3', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="F4" <?php echo (in_array('F4', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="F5" <?php echo (in_array('F5', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td></td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="F6" <?php echo (in_array('F6', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="F7" <?php echo (in_array('F7', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="F8" <?php echo (in_array('F8', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="F9" <?php echo (in_array('F9', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="F10" <?php echo (in_array('F10', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" class="sts[]" value="F11" <?php echo (in_array('F11', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="F12" <?php echo (in_array('F12', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                    </tr>

                    <tr>
                        <td>G</td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G1" <?php echo (in_array('G1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G2" <?php echo (in_array('G2', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G3" <?php echo (in_array('G3', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G4" <?php echo (in_array('G4', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G5" <?php echo (in_array('G5', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td></td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G6" <?php echo (in_array('G6', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G7" <?php echo (in_array('G7', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G8" <?php echo (in_array('G8', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G9" <?php echo (in_array('G9', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G10" <?php echo (in_array('G10', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G11" <?php echo (in_array('G11', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="G12" <?php echo (in_array('G12', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                    </tr>

                    <tr>
                        <td>H</td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H1" <?php echo (in_array('H1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H2" <?php echo (in_array('H2', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H3" <?php echo (in_array('H3', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H4" <?php echo (in_array('H4', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H5" <?php echo (in_array('H5', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td></td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H6" <?php echo (in_array('H6', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H7" <?php echo (in_array('H7', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H8" <?php echo (in_array('H8', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H9" <?php echo (in_array('H9', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H10" <?php echo (in_array('H10', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H11" <?php echo (in_array('H11', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="H12" <?php echo (in_array('H12', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                    </tr>

                    <tr>
                        <td>I</td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I1" <?php echo (in_array('I1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I2" <?php echo (in_array('I2', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I3" <?php echo (in_array('I3', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I4" <?php echo (in_array('I4', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I5" <?php echo (in_array('I5', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td></td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I6" <?php echo (in_array('I6', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I7" <?php echo (in_array('I7', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I8" <?php echo (in_array('I8', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I9" <?php echo (in_array('I9', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I10" <?php echo (in_array('I10', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I11" <?php echo (in_array('I11', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="I12" <?php echo (in_array('I12', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                    </tr>

                    <tr>
                        <td>J</td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J1" <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J2"  <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J3"  <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J4" <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J5" <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td></td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J6" <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J7" <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J8" <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J9" <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J10" <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J11" <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                        <td>
                            <input type="checkbox" name="sts[]" class="seats" value="J12" <?php echo (in_array('J1', $seats)) ? 'checked disabled' : '';?>>
                        </td>
                    </tr>
                </table>

                <div class="screen">
                    <h2 class="wthree">Direction this way</h2>
                </div>
                <button id="cnfrmSel" name="submit">Confirm Selection</button>
            </div>

        </form>
        <?php
        if(isset($_POST['submit'])){
            //$name = $_POST['name'];
            $username = implode(',',$_POST['Username']);

            $userage = implode(',',$_POST['userage']);
           /* echo '<pre>';
            print_r($userage);
            echo '</pre>';
             exit;*/
            $f_id = $_POST['f_id'];
            $seats = $_POST['sts'];
            $Numseats = count($seats);
            //echo $len; exit;
            $seats = implode(',',$_POST['sts']);
            $amount = $_POST['amount'];
            $total_amt = $amount*$Numseats;
            $query = mysqli_query($con, "SELECT * FROM seats WHERE seats_no = '$seats' AND flight_id = '$f_id'");
            $res = mysqli_fetch_assoc($query);
            if(mysqli_num_rows($res)){
                echo "Seats are already reserved";
            }else{
            $sql = mysqli_query($con,"INSERT INTO seats (user_email, user_name, age, flight_id, seats_no, total_seats, price) VALUES('$email', '$username', '$userage', '$f_id', '$seats','$Numseats', '$total_amt')");
            echo "<script>alert('Seat Booked Successfully')</script>";
            //echo $seats?'':'disabled="disabled"';
        }
    }
    ?>

            <!-- //details after booking displayed here -->

            <!-- //seat layout -->
            <!-- details after booking displayed here -->
            <div class="after-confirm">
             <div class="displayerBoxes txt-center" style="overflow-x:auto;">
                <table class="Displaytable w3ls-table" width="100%">
                    <tr>
                        <th>Name</th>
                        <th>Total Seats</th>
                        <th>Total Price</th>
                    </tr>
                    <tr>
                        <??>
                        <td>
                            <textarea id="nameDisplay"><?php if(isset($_POST['submit'])){ echo implode(',',$_POST['Username']); } ?></textarea>
                        </td>
                       
                        <td>
                            <textarea id="Totalseats"> <?php if(isset($_POST['submit'])){ echo count($_POST['sts']); } ?></textarea>
                        </td>
                        <td>
                            <textarea id="seatsPrice"><?php if(isset($_POST['submit'])){ echo $total_amt; }?></textarea>
                        </td>
                    </tr>
                </table>
            </div>
            <div class="submit-class">
                <a href="ticket.php?id='<?php echo base64_decode($_GET['id']); ?> &amp;dept=<?php echo $_GET['dept']; ?> &amp;arival=<?php echo $_GET['arival']; ?> &amp;deptdate=<?php echo $_GET['deptdate']; ?> &amp;arivaldate=<?php echo $_GET['arivaldate']; ?>'" class="print_ticket" type="download">Download Ticket</a>
            </div> 
        </div>
        </div>
    
    </div>
    <div class="copy-wthree">
        <p>© 2019 Yatra.com . All Rights Reserved
        </p>
    </div>
    <!-- js -->
    <script src="js/jquery-2.2.3.min.js"></script>
    <!-- //js -->
    <!-- script for seat selection -->
    <script>
        $(".seats").on('click',function(e) {
        var Selected = $(".seats:checked");
        var numSelected = Selected.length;
        //alert("numSelected: " + numSelected);\
        $('#Numseats').val(numSelected);      
});
        /*$('document').ready(function(){
            $('#cnfrmSel').click(function(){
                var name = $('#Username').val();
                var Numseats = $('#Numseats').val();
                if($('.seats:checked').length  === 0) {
                     alert('Select seat first');
                }
                var form = $('#BookingForm')[0];
                var formData = new FormData(form); 

                formData.append('sts', $('input[name=sts]')); 
                $.ajax({
                type: "POST",
                url: "modules/book_seat.php",
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function(result){
                   alert(result);
                }
            });

            });
        });*/
        /* $(".seats").on('click',function(e) {
        var Selected = $(".seats:checked");
        var numSelected = Selected.length;
        //alert("numSelected: " + numSelected);\
        $('#Totalseats').val(numSelected);      
});*/
    $('input[type=checkbox]').click(function(){
    if(this.checked) {
        $(this).parent().css('background','green');
    } else {
        $(this).parent().css('background','');
    }
});

$(document).ready(function(){
      var i=1;
     $("#add_row").click(function(){
      $('.mr_agilemain'+i).html("<td>"+ (i+1) +"</td><td><input name='name"+i+"' type='text' placeholder='Name' class='form-control input-md'  /> </td><td><input  name='mail"+i+"' type='text' placeholder='Mail'  class='form-control input-md'></td><td><input  name='mobile"+i+"' type='text' placeholder='Mobile'  class='form-control input-md'></td>");

      $('#tab_logic').append('<tr id="addr'+(i+1)+'"></tr>');
      i++; 
  });
     $("#delete_row").click(function(){
         if(i>1){
         $(".mr_agilemain"+(i-1)).html('');
         i--;
         }
     });

});
/**/

    </script>
    <!-- //script for seat selection -->
</section>
</body>

</html>