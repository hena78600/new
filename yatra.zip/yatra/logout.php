<?php
SESSION_start();
SESSION_destroy();
header('location:index.php');
?>