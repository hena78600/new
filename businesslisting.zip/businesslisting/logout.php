<?php
session_start();
//unset($_SESSION['users']);
session_destroy();
$email = $_COOKIE['email'];
$pass =  $_COOKIE['pass'];
setcookie('email', $email, time()-1);
setcookie('pass', $pass, time()-1);
header('location:index.php');

?>