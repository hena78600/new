<?php
    //include('function.php');
    //$con = connect_db();
//print_r($_COOKIE);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Business Listing</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
</head>
<body>
    <nav class="navbar navbar-default nav-main-bar">
  <div class="container">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">Business Listing</a>
    </div>
    <!-- <ul class="nav navbar-nav">
      <li class="active"><a href="#">Home</a></li>
      <li><a href="#">Page 1</a></li>
      <li><a href="#">Page 2</a></li>
    </ul> -->
     <div class="nav-btn pull-right">
        <?php if(isset($_SESSION['users'])){ ?>
        <a href="logout.php" class="btn btn-primary">Logout</a>  
<?php }else{ ?>
      <a class="btn btn-primary" data-toggle="modal" data-target="#myModal" >Sign In</a> <?php } ?> 
      <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">
                    ×</button>
                <h4 class="modal-title" id="myModalLabel">
                    Sign In/Sign Up -</h4>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-12" style="border-right: 1px dotted #C2C2C2;padding-right: 30px;">
                        <!-- Nav tabs -->
                        <ul class="nav nav-tabs">
                            <li class="active"><a href="#Login" data-toggle="tab">Sign In</a></li>
                            <li><a href="#Registration" data-toggle="tab">Sign Up</a></li>
                        </ul>
                        <!-- Tab panes -->
                        <div class="tab-content">
                            <div class="tab-pane active" id="Login">
                                <form role="form" class="form-horizontal" method="POST" id="Login_Form" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label for="inputemail" class="col-sm-2 control-label">
                                            Email</label>
                                        <div class="col-sm-10">
                                            <input type="email" class="form-control" id="inputemail" name="inputemail" value="<?php if(isset($_COOKIE["email"])) { echo $_COOKIE["email"]; } ?>" placeholder="Email"  />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="InputPassword1" class="col-sm-2 control-label">
                                            Password</label>
                                        <div class="col-sm-10">
                                            <input type="password" class="form-control" id="InputPassword1" name="InputPassword1" value="<?php if(isset($_COOKIE["pass"])) { echo $_COOKIE["pass"]; } ?>" placeholder="*****"  />
                                            <p id="val_pass"></p>
                                        </div>
                                    </div>
                                    <div class="form-group">

                                        <div class="col-sm-2">
                                            <input type="checkbox" name="RememberMe" value="1" <?php if(isset($_COOKIE['RememberMe'])) {  echo 'checked="checked"';  } ?>  id="RememberMe" />
                                        </div>
                                        <div class="class="col-sm-10 ">
                                            <label for="RememberMe" class="control-label remember-login">Remember my login</label>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-2">
                                        </div>
                                        <div class="col-sm-10">                                            
                                                <input type="submit" name="submit" class="btn btn-primary btn-sm" value="Sign In">
                                                <span id="loginResult"></span>
                                            <a href="forgot_password.php">Forgot your password?</a>
                                        </div>
                                        <p id="val_cred"></p>
                                    </div>
                                </form>
                            </div>
                            <div class="tab-pane" id="Registration">
                                <form role="form" action= "#" class="form-horizontal" method="POST" id="Register_Form" onsubmit="return validate();">
                                <div class="form-group">
                                    <label for="inputname" class="col-sm-2 control-label">
                                        Owner Name</label>
                                    <div class="col-sm-10">
                                        <div class="row">
                                          
                                            <div class="col-md-12">
                                                <input type="text" class="form-control" name="user_name" id="inputname" placeholder="Name"  />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="bus_name" class="col-sm-2 control-label">
                                        Business Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="bus_name" id="bus_name" placeholder="Business Name"  />
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="bus_cat" class="col-sm-2 control-label">
                                        Business Category</label>
                                    <div class="col-sm-10">
                                        <select class="form-control" name="bus_cat" id="bus_cat">
                                            <?php 
                                            $sql = mysqli_query($con, "SELECT cat_name FROM business_category");
                                            while($row = mysqli_fetch_assoc($sql)){
                                            ?>
                                            <option><?php echo $row['cat_name']; ?></option>
                                            <?php
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">
                                        Email</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="email" id="email" placeholder="Email"  />
                                        <p id="valid_email"></p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="Inputmobileno" class="col-sm-2 control-label">
                                        Mobile</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="Inputmobileno" id="Inputmobileno"  placeholder="Mobile"  /><p id="valid_mobile"></p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="Input_pass" class="col-sm-2 control-label">
                                        Password</label>
                                    <div class="col-sm-10">
                                        <input type="password" class="form-control" name="Input_pass" id="Input_pass" placeholder="Password" /><span id="validatepass" style="color: rgb(255, 155, 55);"></span>
                                        <p id="valid_pass"></p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputAddress" class="col-sm-2 control-label">
                                        Address</label>
                                    <div class="col-sm-10">
                                        <textarea class="form-control" name="inputAddress" id="inputAddress" placeholder="Address"></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="bus_logo" class="col-sm-2 control-label">
                                        Business Logo</label>
                                    <div class="col-sm-10">
                                        <input type="file" id="bus_logo" name="bus_logo" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="date_estab" class="col-sm-2 control-label">
                                        Date Of Establishment</label>
                                    <div class="col-sm-10">
                                        <input type="text" name="date_estab" id="datepicker" class="form-control" placeholder="Date of Establishment">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="news" class="col-sm-2 control-label">
                                        Subscribe to newsletter</label>
                                    <div class="col-sm-10">
                                        <input type="radio" name="subscribe" value="Yes">Yes

                                    <input type="radio" name="subscribe" value="No">No
                                <p id="valid_news"></p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="hear_abt" class="col-sm-2 control-label">
                                        How do you hear about us</label>
                                    <div class="col-sm-10">
                                       <?php 

                                       ?>
                                        <input type="checkbox" class="tv" name="ch[]" id="tvad" value="tvad">TV Ads
                                        <input type="checkbox" class="tv" name="ch[]" id="newspaper" value="newspaper">Newspaper
                                        <input type="checkbox" class="tv" name="ch[]" id="wordofmouth"  value="wordofmouth">Word Of Mouth 
                                        <input type="checkbox" class="tv" id="Others"  value="others">Others
                                    </div>
                                    <div class="col-sm-10">
                                        <input type="text" id="inputothers" name="ch[]" placeholder="Others Please Mention" class="form-control" style="display: none;">
                                        <p id="valid_abt"></p>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="desc" class="col-sm-2 control-label">
                                       Business description</label>
                                        
                                    <div class="col-sm-10">
                                        <input type="text" id="desc" name="desc" placeholder="Business description" class="form-control">
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    
                                    <div class="col-sm-10">
                                        <input type="submit" name="submit" class="btn btn-primary btn-sm" value="Sign Up">
                                        <input type="reset" name="cancel" class="btn btn-default btn-sm" value="Cancel">
                                    <div id="Result"></div>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                        <!-- <div id="OR" class="hidden-xs">
                            OR</div> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>     
     </div>
  </div>
</nav>
<script>

    function validate(){
           var flag  = true;

         var name = $('#inputname').val().trim();
              if (name == "") {
                flag = false;
                $('#inputname').css("border-color","red");
              } else {
                $('#inputname').css("border-color","");
              }

        var bus_name = $('#bus_name').val().trim();

         if (bus_name == "") {
                flag = false;
                $('#bus_name').css("border-color","red");
              } else {
                $('#bus_name').css("border-color","");
              }

           var bus_cat = $('#bus_cat').val();

         if (bus_cat == "") {
                flag = false;
                $('#bus_cat').css("border-color","red");
              } else {
                $('#bus_cat').css("border-color","");
              }

              
              var email = $('#email').val().trim();
              $('#valid_email').html();
                var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
               if (email == "" || !re.test(String(email).toLowerCase())){
                   flag = false;
                   $('#email').css("border-color","red");
                   $('#valid_email').html('<h6 class="text-danger pull-right">*Enter a valid Email</h6>');
               } else {
                   $('#email').css("border-color","");
                   $('#valid_email').html("");
               }

                var Inputmobileno = $('#Inputmobileno').val().trim();
                if (Inputmobileno == "" || isNaN(Inputmobileno) || Inputmobileno.length !=10){
                    flag = false;
                $('#Inputmobileno').css("border-color","red");
                $('#valid_mobile').html('<h6 class="text-danger pull-right">*Enter valid Mobile Number</h6>');
                } else {
                  $('#Inputmobileno').css("border-color","");
                  $('#valid_mobile').html("");
                }

                var pass = $('#Input_pass').val().trim();
                var regularExpression = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/;

                $('#valid_pass').html('');
                if (pass == ""){
                    flag = false;
                $('#Input_pass').css("border-color","red");
                $('#valid_pass').html('<h6 class="text-danger pull-right">*Enter a strong Password </h6>');
                }else if(!regularExpression.test(pass)){
                    $('#Input_pass').css("border-color","red");
                    $('#valid_pass').html('<h6 class="text-danger pull-right">*Enter atleast one numbers and special characters</h6>');
                }else if(pass.length < 8 || pass.length >10 ){
                    $('#Input_pass').css("border-color","red");
                    $('#valid_pass').html('<h6 class="text-danger pull-right">*Enter Eight to Ten characters </h6>');
                } else {
                  $('#Input_pass').css("border-color","");
                }

                var inputAddress = $('#inputAddress').val().trim();
                 if (inputAddress == "") {
                        flag = false;
                        $('#inputAddress').css("border-color","red");
                      } else {
                        $('#inputAddress').css("border-color","");
                      }

                var bus_logo = $('#bus_logo').val();
                 if (bus_logo == "") {
                        flag = false;
                        $('#bus_logo').css("border-color","red");
                      } else {
                        $('#bus_logo').css("border-color","");
                      }

                var date_estab = $('#datepicker').val().trim();
                 if (date_estab == "") {
                        flag = false;
                        $('#datepicker').css("border-color","red");
                      } else {
                        $('#datepicker').css("border-color","");
                      }

                 var news = $("input[name='subscribe']").val();
                 if($('input[name="subscribe"]:checked').length  === 0) {
                    flag = false;
                     $('#valid_news').html('<h6 class="text-danger pull-right">*Select atleast one</h6>');
                }else {
                    $('#valid_news').html("");
                      }
                 //alert($('input[name="news"]:checked').val());

                 if ($(".tv:checked").length == 0 ) {
                      flag = false;
                       $('#valid_abt').html('<h6 class="text-danger pull-right">*Check atleast one</h6>');
                } else {
                        $('#valid_abt').html("");
                }

           /*if ($("input[name='ch']:checked").length == 0 ) {
                   if ($("#others").val().trim() == ""){
                      flag = false;
                       $('#valid_abt').html('<h6 class="text-danger pull-right">*Check atleast one</h6>');
                   }else{
                        $('#valid_abt').html("");
                   }
                } else {
                        $('#valid_abt').html("");
             }*/

                //alert(hear_abt);
                /*if($('#hear_abt:checked').length == 0){
                    flag = false;
                    $('valid_abt').html('<h6 class="text-danger pull-right">*Check atleast one</h6>');
                }else {
                        $('valid_abt').html("");
                      }*/
                 /*if (hear_abt == "") {
                        flag = false;
                        $('#hear_abt').css("border-color","red");
                      } else {
                        $('#hear_abt').css("border-color","");
                      }*/

                var desc = $('#desc').val().trim();
                 if (desc == "") {
                        flag = false;
                        $('#desc').css("border-color","red");
                      } else {
                        $('#desc').css("border-color","");
                      }
 if (flag === false){
    return false;
  }

                var form = $('#Register_Form')[0];
                var formData = new FormData(form); 

                formData.append('news', $('input[name=news]')); 
                //formData.append('image', $('input[type=file]')[0].files[0]); 
               
                //var dataString = "name="+name+"&bus_name="+bus_name+"&bus_cat="+bus_cat+"&email="+email+"&Inputmobileno="+Inputmobileno+"&pass="+pass+"&inputAddress="+inputAddress+"&bus_logo="+bus_logo+"&date_estab="+date_estab+"&news="+news+"&desc="+desc;
                //alert(dataString);
                
                $.ajax({
                type: "POST",
                url: "modules/users.php",
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function(result){
                   //alert(result);
                   if(result == 'success'){
                    //$("#Register_Form").get(0).reset;
                   // $("#Register_Form")[0].reset();
                    //$('#Result').html('<p class="text-info pull-right">'+result+'</p>');
                    alert(result);
                    
                   }else{
                    /*$("#Register_Form")[0].reset();*/
                    $('#Result').html('<p class="text-info pull-right">'+result+'</p>');
                   }
                }
            });
            
  return false;
   }
</script>
<script>        
    $('#Login_Form').submit(function(any){
        any.preventDefault();
        var email = $('#inputemail').val();
        var pass = $('#InputPassword1').val();
         var RememberMe = 0;
        if( $('#RememberMe').is(":checked")){
           RememberMe =  $('#RememberMe').val();
        }
        //alert( RememberMe);
        //return false;
        if(email == '' || pass == ''){
            $('#inputemail').css("border-color", "red");
            $('#InputPassword1').css("border-color", "red");
            $('#val_cred').html('<h6 class="text-danger pull-right">Provide Email and Password</h6>');
        }
        else{
        var dataString = "inputemail="+email+"&inputpass="+pass+"&RememberMe="+RememberMe;
        //alert(dataString);
        //console.log(dataString);
             //return false;
        $.ajax({
            type: "POST",
            url: "modules/users.php",
            data: dataString,
            cache: false,
            success: function(result){
                if(result === 'Success'){
                    window.location.href = 'profile.php';
                    }else{
                        $('#val_cred').html('<h6 class="text-danger pull-right">'+result+'</h6>');
                    }
                }
        });
        return false;
    }
    });
    //console.log(document.cookie);
</script>
<script>
$(document).ready(function(){
    $('input:checkbox').click(function() {
        $('input:checkbox').not(this).prop('checked', false);
    });
});
$( function() {
    $( "#datepicker" ).datepicker();
  });
$(function () {
        $("#Others").click(function () {
            if ($(this).is(":checked")) {
                $("#inputothers").show();
            } else {
                $("#inputothers").hide();
            }
        });
    });
</script>

