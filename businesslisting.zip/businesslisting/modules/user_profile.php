<?php include '../function.php';
$con = connect_db(); 
?>
<?php
	/*echo "<pre>";
	print_r($_POST);
	print_r($_FILES);
	echo "</pre>";*/
if(isset($_POST['name'])){
	$name = $_POST['name'];
	//echo $name; exit;
	$business_name = $_POST['business_name'];
	$business_cat = $_POST['business_cat'];
	$email = $_POST['InputEmail'];
	$mob = $_POST['InputMobile'];
	$add = $_POST['Inputaddress'];
	
	//$logo = $_FILES['business_logo'];

	$date = $_POST['date_of_estab'];
	$news = $_POST['InputNews'];
	$hearabt = $_POST['Inputtvad'];
	$desc = $_POST['Inputdesc'];
	//$img = $_FILES['business_logo'];
	$targetDir = "../uploads/";
	$fileName = basename($_FILES['business_logo']['name']);
	$targetFilePath = $targetDir . $fileName;
	$fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
	$allowType = array('jpg', 'png', 'jpeg','gif');
	if(in_array($fileType, $allowType)){
		if(move_uploaded_file($_FILES['business_logo']['tmp_name'], $targetFilePath)){

	if($sql = mysqli_query($con, "UPDATE users SET name = '$name', bus_name = '$business_name', bus_cat = '$business_cat', mobile = '$mob',address = '$add',logo = '$fileName',dateofestab = '$date',newsletter = '$news',howtohear = '$hearabt', description = '$desc' WHERE email = '$email'")){
		echo "Updated Successfully";
	}else{
		echo "Couldn't update";
	}
}
}
}


?>