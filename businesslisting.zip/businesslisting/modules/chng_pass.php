<?php include '../function.php';

if(isset($_POST['rec_pass'], $_POST['con_pass'])){
	$email = $_SESSION['users'];
	$rec_pass = md5($_POST['rec_pass']);
	$new_pass = md5($_POST['new_pass']);
	$con_pass = md5($_POST['con_pass']);
	//echo $con_pass; exit;
	$sql = mysqli_query($con, "SELECT password FROM users WHERE email = '$email'");
	$row = mysqli_fetch_assoc($sql);
	$pass = $row['password'];
	if($new_pass != $con_pass){
		echo "Password Mismatched";
	}else if($rec_pass === $pass ){
		$change = mysqli_query($con, "UPDATE users SET password = '$con_pass' WHERE email = '$email'");
		echo "Password Changed Successfully";
	}else{
		echo "Invalid Current Password";
	}
}
?>
