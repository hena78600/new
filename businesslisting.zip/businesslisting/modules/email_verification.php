<?php
include('../function.php');
if(isset($_GET['activation_code'])){
	$code = $_GET['activation_code'];
	$sql = mysqli_query($con, "SELECT * FROM users WHERE activation_code = '$code'");
	$row = mysqli_fetch_assoc($sql);
	$email_status = $row['email_status'];
	//echo $email_status; exit;
	if($email_status === 'not verified'){
		$update = mysqli_query($con, "UPDATE users SET email_status = 'verified' WHERE activation_code = '$code'");
		echo "<html>Your Email Address Successfully Verified </html>";
	}else{
		echo "<html>Your Email Address Already Verified</html>";
	}
}



?>