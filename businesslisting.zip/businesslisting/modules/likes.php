<?php
include('../function.php');
if(isset($_POST['id'])){
	$id = $_POST['id'];
	//echo $id;
	if(isset($_SESSION['users'])){
		$email = $_SESSION['users'];
		$check = mysqli_query($con, "SELECT * FROM bus_like WHERE bus_id = '$id' AND user_email = '$email'");
		if(mysqli_num_rows($check) > 0 ){
			$del = mysqli_query($con, "DELETE FROM bus_like WHERE bus_id = '$id' AND user_email = '$email'");
			echo "success";
		}else{
			$insert = mysqli_query($con, "INSERT INTO bus_like (bus_id, user_email) VALUES('$id', '$email') ");
			echo "success";
		}
	}else{
		echo "You must sign in to like";
	}
}


?>