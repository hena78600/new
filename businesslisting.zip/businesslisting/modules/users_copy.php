<?php
/*echo '<pre>';
print_r($_POST);
print_r($_FILES);
die;*/
require '../function.php';
if(isset($_POST['user_name'], $_POST['bus_name'])){
	/*echo "<pre>";
	print_r($_FILES);
	echo"</pre>";
	echo "<pre>";
	print_r($_POST);
	echo"</pre>";*/
	$name = $_POST['user_name'];
	//echo $name; exit;
	$bus_name = $_POST['bus_name'];
	$bus_cat = $_POST['bus_cat'];
	$email = $_POST['email'];
	$Inputmobileno = $_POST['Inputmobileno'];
	//echo $Inputmobileno; exit;
	$pass = $_POST['Input_pass'];

	$inputAddress = $_POST['inputAddress'];
	$date_estab = $_POST['date_estab'];
	$news = $_POST['news'];
	$hear_abt = implode(',',$_POST['ch']);
	$descr = $_POST['desc'];
	$valid_extensions = array('jpeg', 'jpg', 'png', 'gif'); // valid extensions
	$path = 'uploads/'; // upload directory
	
	$img = $_FILES['bus_logo']['name'];
	$tmp = $_FILES['bus_logo']['tmp_name'];
	 
	// get uploaded file's extension
	$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));
	 
	// can upload same image using rand function
	$final_image = rand(1000,1000000).$img;
	 
	// check's valid format
	if(in_array($ext, $valid_extensions)) 
	{ 
	$path = $path.strtolower($final_image); 
	 
	if(move_uploaded_file($tmp,$path)) 
	{
	

	$check = mysqli_query($con, "SELECT * FROM users WHERE email='$email'");
	if(mysqli_num_rows($check) > 0 ){
		echo "Email Id already registered";
	}else{
		mysqli_query($con, "INSERT INTO users(name, bus_name, bus_cat, email, mobile, password, address, logo, dateofestab, newsletter,howtohear, description, status) VALUES ('$name', '$bus_name', '$bus_cat', '$email', '$Inputmobileno', '$pass', '$inputAddress', '$path', '$date_estab', '$news','$hear_abt', '$descr', 'PENDING')");
        echo 'Registered successfully You can now Sign In';
    }
}
}
}
if(isset($_POST['inputemail'], $_POST['inputpass'])){
	$email = $_POST['inputemail'];
	$pass = $_POST['inputpass'];
	$RememberMe = $_POST['RememberMe'];
	$check = mysqli_query($con, "SELECT * FROM users WHERE email='$email' AND password='$pass'");
	if(mysqli_num_rows($check) == 0){
		echo "Invalid Email or Password";
	}elseif(!empty($_POST["RememberMe"])){
		setcookie('inputemail', $email, time()+60*60*7);
		setcookie('inputpass', $pass. time()+60*60*7);
		$row = mysqli_fetch_assoc($check);
		$email = $row['email'];
		$_SESSION['users'] = $email;
		//echo "Success";
		/*header("Location: ../profile.php");*/
		echo '<script> window.location.href = "profile.php";</script>';
	}
}


/*File uplaod code*/

   
