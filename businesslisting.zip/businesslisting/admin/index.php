<?php include('header.php'); ?>
<section class="login-admin-sec">
  <div class="container">
    <div class="row">
      <div class="col-md-6 col-md-offset-3">
        <h2>Login</h2><br>
          <form role="form" class="form-horizontal" method="POST" id="Login_Form">
                                    <div class="form-group">
                                        <label for="inputemail" class="col-sm-2 control-label">
                                            Email</label>
                                        <div class="col-sm-10">
                                            <input type="email" class="form-control" id="inputemail" placeholder="Email" />
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label for="InputPassword1" class="col-sm-2 control-label">
                                            Password</label>
                                        <div class="col-sm-10">
                                            <input type="password" class="form-control" id="InputPassword1" placeholder="*****"  />
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-2">
                                        </div>
                                        <div class="col-sm-10">                                            
                                                <input type="submit" name="submit" class="btn btn-primary btn-sm" value="Submit">
                                                <span id="loginResult"></span>
                                            <a href="forgot_password.php">Forgot your password?</a>
                                        </div>
                                    </div>
                                </form>
    </div>
  </div>  
</section>
<script>        
    $('#Login_Form').submit(function(any){
        any.preventDefault();
        var email = $('#inputemail').val();
        var pass = $('#InputPassword1').val();
        var dataString = "inputemail="+email+"&inputpass="+pass;
        /*alert(dataString);*/
        $.ajax({
            type: "POST",
            url: "modules/admin_user.php",
            data: dataString,
            cache: false,
            success: function(result){
                if(result === 'success'){
                    window.location.replace('business_list.php');
                    }else{
                        $('#loginResult').html('<span>'+result+'</span>');
                    }
                }
        });
    });
</script>

