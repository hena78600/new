<?php
session_start();
/*Connecting to Database*/
function connect_db(){
	$con = mysqli_connect('localhost', 'root', '', 'businesslisting');
	if($con){
		return $con;
	}else{
		die('Database connectivity Error');
	}
}
?>