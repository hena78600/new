<?php 
include 'header.php'
?>
<section class="frgt_pass"> 
	<div class="container">
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
            <div class="panel panel-default">
              <div class="panel-body">
                <div class="text-center">
                  <h3><i class="fa fa-lock fa-4x"></i></h3>
                  <h2 class="text-center">Forgot Password?</h2>
                  <p>You can reset your password here.</p>
                  <div class="panel-body">
    
                    <form id="forgot_Pass" class="form" method="POST" onsubmit="return validate(); ">
    
                      <div class="form-group">
                        <div class="input-group">
                          <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                          <input type="text" placeholder="Email Address" id="inputEmail" class="form-control">
                        </div>
                      </div>
                      <div class="form-group">
                        <input type="submit" class="btn btn-lg btn-primary btn-block" value="Reset Password" >
                      </div>
                      <div id="result_pass"></div>
                      
                    </form>
    
                  </div>
                </div>
              </div>
            </div>
          </div>
	</div>
</div>
</section>
<script>
	function validate(){
		var flag  = true;
		var email = $('#inputEmail').val().trim();
		var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if (email == "" || !re.test(String(email).toLowerCase())){
            flag = false;
                alert('Please provide valid Email')
        }
        if(email != ''){
        	var dataString = "email="+email;
        	$.ajax({
                type: "POST",
                url: "modules/forgot_pass.php",
                data: dataString,
                cache: false,
                success: function(result){
                   alert(result);
                }
            });
        }
		
	}
	
</script>


<!-- <?php //include 'footer.php'; ?> -->