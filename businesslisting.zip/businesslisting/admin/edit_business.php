<?php include('header.php');
include('sidebar.php'); 
$con = connect_db();
if(isset($_GET['id'])){
$id = $_GET['id'];
$sql = mysqli_query($con, "SELECT * FROM users WHERE id = '$id'");
$row = mysqli_fetch_assoc($sql);

?>
<section class="sec-profile-admn">
<div class="container">
	<div class="row">
		<div class="col-lg-6 col-xlg-9 col-md-7 col-md-offset-2">
                        <div class="card">
                            <div class="card-block">
                                 <ul class="nav nav-tabs">
                                    <li class="active"><a data-toggle="tab" href="#home">Edit Business</a></li>
                                    
                                  </ul>
                                  <div class="tab-content">
                                    <div id="home" class="tab-pane fade in active">
                                        <form role="form" class="form-horizontal" method="POST" action="" id="profile_Form" enctype="multipart/form-data">
                                <div class="form-group">
                                    <label for="name1" class="col-sm-2 control-label">
                                        Name</label>
                                    <div class="col-sm-10">
                                        <div class="row">                                          
                                            <div class="col-md-12">
                                                <input type="text" class="form-control" id="name1" name="name1" value="<?php echo $row['name']; ?>" placeholder="Name" required>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="business_name" class="col-sm-2 control-label">
                                        Business Name</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="business_name" name="business_name" value="<?php echo $row['bus_name']; ?>"  placeholder="Business Name"  required/>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="business_cat" class="col-sm-2 control-label">
                                        Business Category</label>
                                    <div class="col-sm-10">
                                        <?php $bus_cat = $row['bus_cat']; ?>

                                        <select class="form-control" id="business_cat" name="business_cat" required>  
                                            <?php 
                                            $sql = mysqli_query($con, "SELECT * FROM business_category");
                                            while($fetch = mysqli_fetch_array($sql)){
                                            ?>
                                            <option value="<?php echo $fetch['cat_name'];?>" <?php echo $select = ($bus_cat==$fetch['cat_name']) ? 'selected':''?>><?php echo $fetch['cat_name'];?></option>

                                            
                                            <?php
                                            } ?>
                                            
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="inputemail" class="col-sm-2 control-label">
                                        Email</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" name="inputemail" value="<?php echo $row['email']; ?>" placeholder="Email" id="mailinput" readonly required/>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="InputMobile" class="col-sm-2 control-label">
                                        Mobile</label>
                                    <div class="col-sm-10">
                                        <input type="text" class="form-control" id="InputMobile" name="InputMobile" value="<?php echo $row['mobile']; ?>"  placeholder="Mobile" required/><span id="message">
                                    </div>
                                </div>                                
                                <div class="form-group">
                                    <label for="Inputaddress" class="col-sm-2 control-label">
                                        Address</label>
                                    <div class="col-sm-10">
                                    	<textarea class="form-control" id="Inputaddress" name="Inputaddress" value="<?php echo $row['address']; ?>" placeholder="Address" required><?php echo $row['address']; ?></textarea>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="logo" class="col-sm-2 control-label">
                                        Business Logo</label>
                                    <div class="col-sm-10">
                                    	<input type="file" name="logo" class="form-control" required>
	                                </div>
                                    <div class="col-sm-12"></div>
                                    <div class="col-sm-6 col-sm-offset-3">
                                        <img src="<?php echo '../uploads/'.$row['logo']; ?>" class="ret_img" height="150px">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="date_of_estab" class="col-sm-2 control-label">
                                        Date Of Establishment</label>
                                    <div class="col-sm-10">
                                    	<input type="text" id="datepicker" name="date_of_estab" value="<?php echo $row['dateofestab']; ?>" class="form-control" required>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="InputNews" class="col-sm-2 control-label">
                                        Subscribe to newsletter</label>
                                    <div class="col-sm-10">
                                        <?php $news = $row['newsletter']; ?>
                                        <input type="radio" class="InputNews" name="news" value="Yes" <?php if($row['newsletter']=="Yes"){ echo "checked";}?>> Yes
                                    	<input type="radio" name="news" class="InputNews" <?php if($row['newsletter']=="No") {echo "checked"; }?> value="No">No
                                    </div>

                                </div>
                                <div class="form-group">
                                    <label for="Inputtvad" class="col-sm-2 control-label">
                                       	How do you hear about us</label>
                                    <div class="col-sm-10">
                                    	<input type="checkbox" name="ch" value="tvad"  <?php if($row['howtohear']=="tvad"){ echo "checked";} ?> >TV Ads
										<input type="checkbox" name="ch" value="newspaper"  <?php if($row['howtohear']=="newspaper"){ echo "checked";}?> >Newspaper
										<input type="checkbox" name="ch" value="wordofmouth"  <?php if($row['howtohear']=="wordofmouth"){ echo "checked";}?> >Word Of Mouth
                                    </div>
                                    <div class="col-sm-10">
                                    	<input type="text" name="newspaper" placeholder="Others Please Mention" class="form-control">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="Inputdesc" class="col-sm-2 control-label">
                                       Business description</label>
                                    	
                                    <div class="col-sm-10">
                                    	<input type="text" id='Inputdesc' name="Inputdesc" value="<?php echo $row['description']; ?>" placeholder="Business description" class="form-control" required>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-2">
                                    </div>
                                    <div class="col-sm-10">
                                        <input type="submit" id="submit" name="submit" class="btn btn-primary btn-sm" value="Update">
                                        <input type="reset" name="cancel" class="btn btn-default btn-sm" value="Cancel">
                                        <div id="Result"></div>
                                    </div>
                                </div>
                                </form>
                                <?php 
                                if(isset($_POST['submit'])){
                                    $name = $_POST['name1'];
                                    //echo $name; exit;
                                    $business_name = $_POST['business_name'];
                                    $business_cat = $_POST['business_cat'];
                                    $email = $_POST['inputemail'];
                                    $mob = $_POST['InputMobile'];
                                    $add = $_POST['Inputaddress'];
                                    $date = $_POST['date_of_estab'];
                                    $news = $_POST['news'];
                                    /*if(!isset($_POST['ch'])){ ?>
                                    <label for="check" class="error">You must agree to terms</label>
                                    <?php }*/
                                    $hearabt = $_POST['ch'];
                                    //echo $hearabt; exit;
                                    $desc = $_POST['Inputdesc'];
                                    $targetDir = "../uploads/";
                                    $fileName = basename($_FILES['logo']['name']);
                                    $targetFilePath = $targetDir . $fileName;
                                    $fileType = pathinfo($targetFilePath, PATHINFO_EXTENSION);
                                    $allowType = array('jpg', 'png', 'jpeg','gif');
                                    if(in_array($fileType, $allowType)){
                                        if(move_uploaded_file($_FILES['logo']['tmp_name'], $targetFilePath)){
                                            if($sql = mysqli_query($con, "UPDATE users SET name = '$name', bus_name = '$business_name', bus_cat = '$business_cat', mobile = '$mob',address = '$add',logo = '$fileName',dateofestab = '$date',newsletter = '$news',howtohear = '$hearabt', description = '$desc' WHERE email = '$email'")){
                                            echo "Updated Successfully";
                                            //echo "<script>window.location.href = 'business_details.php'</script>";
                                        }else{
                                            echo "Couldn't update";
                                            /*echo "<script>window.location.reload();</script>";*/
                                        }
                                    }
                                }
                            }

                                ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div>
</div>
</section>
<?php }  ?>

<script>
    $( function() {
    $( "#datepicker" ).datepicker();
  } );
    $(document).ready(function(){
    $('input:checkbox').click(function() {
        $('input:checkbox').not(this).prop('checked', false);
    });
});
</script>



<?php include ('footer.php'); ?>