<?php include('header.php'); ?>
<?php include('sidebar.php'); ?>
<?php 
if(!isset($_SESSION['admin'])){
    header('location:index.php');
}
    $con = connect_db();
    $sql = mysqli_query($con, "SELECT * FROM users WHERE status = 'APPROVED'");

?>
<section class="sec-profile-admn">
<div class="container">
	<div class="row">
		<div class="col-lg-6 col-xlg-9 col-md-7 col-md-offset-2">
                        <div class="card">
                            <div class="card-block">
                                 <ul class="nav nav-tabs">
                                    <li class="active"><a data-toggle="tab" href="#home">Business Details</a></li>
                                    
                                  </ul>
                                  <div class="tab-content">
                                    <div id="home" class="tab-pane fade in active">
                                        <table class="table table-condensed" >
                                        <thead>
                                          <tr>
                                            <th>Name</th>
                                            <th>Business Name</th>
                                            <th>Business Category</th>
                                            <th>Email</th>
                                            <th>Mobile</th>
                                            <th>Operation</th>
                                            <th>Operation</th>
                                          </tr>
                                        </thead>
                                        <tbody><?php 
                                        while($row = mysqli_fetch_assoc($sql)){
                                             ?><tr>
                                            <td><?php echo $row['name']; ?></td>
                                            <td><?php echo $row['bus_name']; ?></td>
                                            <td><?php echo $row['bus_cat']; ?></td>
                                            <td><?php echo $row['email']; ?></td>
                                            <td><?php echo $row['mobile']; ?></td>
                                            <td><a href="addtoarch.php?id=<?php echo $row['id']; ?>">Add to archieved</td>
                                            <td><a href="edit_business.php?id=<?php echo $row['id']; ?>">Business Edit</td>
                                          </tr>
                                          <?php 
                                        }
                                        ?>
                                         
                                         
                                        </tbody>
                                      </table>
                                    </div>
                                    
                                   
                                  </div>

                            </div>
                        </div>
                    </div>
	</div>
</div>
</section>
<!-- <script>  
 $(document).ready(function(){  
      load_data();  
      function load_data(page)  
      {
      //alert('hii');  
           $.ajax({  
                url:"modules/pagination.php",  
                method:"POST",  
                data:{page:page},  
                success:function(data){  
                     $('#home').html(data);  
                }  
           });  
      }  
      $(document).on('click', '.pagination_link', function(){  
           var page = $(this).attr("id");  
           load_data(page);  
      });  
 });  
 </script>  
 -->
<?php include('footer.php'); ?>