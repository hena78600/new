<?php
require '../function.php';
$con = connect_db();
if(isset($_POST['cat_name'])){
	$name = $_POST['cat_name'];
	$check = mysqli_query($con, "SELECT * FROM business_category WHERE cat_name='$name'");
	if(mysqli_num_rows($check) > 0 ){
		echo "Category Already Exist";
	}elseif(mysqli_query($con, "INSERT INTO business_category (cat_name) VALUES('$name'); ")){
		echo "Added Successfully";
	}else{
		echo "Couldn't Add";
	}
}