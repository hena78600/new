<?php
include('../function.php');
$con = connect_db();
$output = '';
if(isset($_POST['order'] , $_POST['column_name'])){
$order = $_POST['order'];
/*echo "<pre>";
print_r ($_POST);
echo "</pre>";*/
if($order == 'desc'){
	$order = 'asc';
}else{
	$order = 'desc';
}
//echo $order;
$result = mysqli_query($con, "SELECT * FROM users ORDER BY ".$_POST['column_name']." ".$_POST["order"]."");
$output .= '
<table class="table table-condensed table-bordered" id="myTable">
                                        <thead>
                                          <tr>
                                            <th><a href="#" class="column_sort" id = "name" data-order="'.$order.'">Name</a></th>
                                            <th><a href="#" class="column_sort" id = "bus_name" data-order="'.$order.'">Business Name</a></th>
                                            <th><a href="#" class="column_sort" id = "bus_cat" data-order="'.$order.'">Business Category</a></th>
                                            <th><a href="#" class="column_sort" id = "email" data-order="'.$order.'">Email</a></th>
                                            <th><a href="#" class="column_sort" id = "mobile" data-order="'.$order.'">Mobile</a></th>
                                            
                                          </tr>
                                        </thead>
';
while($row = mysqli_fetch_assoc($result)){
	$output.= '
	<tr>
	<td>'.$row["name"].'</td>
	<td>'.$row["bus_name"].'</td>
	<td>'.$row["bus_cat"].'</td>
	<td>'.$row["email"].'</td>
	<td>'.$row["mobile"].'</td>
	</tr>
	';
}
$output.='</table>';
echo $output;
}
?>