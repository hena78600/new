<?php
require '../function.php';
$con = connect_db();
if(isset($_POST['inputemail'], $_POST['inputpass'])){
	$email = $_POST['inputemail'];
	$pass = $_POST['inputpass'];
	$check = mysqli_query($con, "SELECT * FROM admin WHERE email='$email' AND password='$pass'");
	if(mysqli_num_rows($check) == 0){
		echo "Invalid Email or Password";
	}else{
		$row = mysqli_fetch_assoc($check);
		$email = $row['email'];
		$_SESSION['admin'] = $email;
		/*echo "Success";*/
		/*header("Location: ../profile.php");*/
		echo '<script> window.location.href = "business_list.php" </script>';
	}
}
if(isset($_POST['cat_name'])){
	$name = $_POST['cat_name'];
	echo $name; exit;
	if(mysqli_query($con, "INSERT INTO business_category (cat_name) VALUES('$name'); ")){
		echo "Added Successfully";
	}else{
		echo "Couldn't Add";
	}
	

}
