<?php include 'function.php';
$con = connect_db();
if(isset($_GET['id'])){
	$id = $_GET['id'];
	$check = mysqli_query($con, "SELECT * FROM arch_user WHERE user_id='$id'");
	$row = mysqli_fetch_assoc($check);
	$user_id = $row['user_id'];
	//echo $type; exit;
	if(mysqli_num_rows($check) > 0){
		$sql = mysqli_query($con, "DELETE FROM arch_user WHERE user_id='$id'");
		echo "<script>alert('Removed from archieved');</script>";
		echo "<script>window.location.href='business_details.php'</script>";
	}else{
		$sql = mysqli_query($con, "INSERT INTO arch_user (user_id) VALUES('$id'); ");
		echo "<script>alert('Added to archieved');</script>";
		echo "<script>window.location.href='business_details.php'</script>";
	}
} 
 ?>

