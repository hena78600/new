<?php include 'function.php';
$con = connect_db();
if(isset($_GET['id'])){
	$id = $_GET['id'];
	$check = mysqli_query($con, "DELETE FROM business_category WHERE id = '$id'");
	echo "<script>alert('Deleted Successfully');</script>";
	echo "<script>window.location.href='business_cat.php'</script>";

}