<?php
include ('function.php');
 include('header.php');
$sql = mysqli_query($con, "SELECT arch_user.user_id, users.id, users.name, users.bus_name, users.bus_cat, users.email, users.mobile, users.logo FROM arch_user, users WHERE arch_user.user_id = users.id");
?>

<!-- Banner -->
<header class="masthead text-white text-center">
    <div class="overlay"></div>
    <div class="container">
      <div class="row">
        <div class="col-xl-9 mx-auto">
          <h1 class="mb-5">Business Listing</h1>
          <p>Find the best places to eat, drink, shop, or visit in any city in the world. Access over 75 million short tips from local experts.</p>
        </div>
        <div class="col-md-12 col-lg-12 col-xl-12 mx-auto ">
          <form action="search.php" method="POST">
            <div class="form-row">
              <div class="col-4 col-md-6">
                <input type="text" name="inputSearch" class="form-control form-control-lg" placeholder="I'm Looking For..." required="">
              </div>
              
              <div class="col-4 col-md-2">
                <input type="submit" name="submit" class="btn btn-block btn-lg btn-primary" value="SEARCH">
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </header>

    <!-- Icons Grid -->
  <div class="container text-center" style="padding-top: 50px;">
    <div class="row">
      <?php
      while($row = mysqli_fetch_assoc($sql)){
        $logo = 'uploads/'.$row['logo'];
                      ?><div class="col-md-3"><a class="thumbnail"><img src="<?php echo $logo; ?>" alt="Image" style="max-width:100%;">
                        <h3><?php echo $row['bus_name']; ?></h3>
                        <p><?php echo $row['bus_cat']; ?></p>
                      </a>
                        
                      </div>
                   <?php } ?>
                      
                    </div><!--.row-->

  </div>
<?php include('footer.php'); ?>