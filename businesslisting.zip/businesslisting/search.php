<?php include ('function.php');
 include ('header.php'); 
 ?>
<?php
if(isset($_POST['inputSearch'])){
$search = $_POST['inputSearch'];
//echo $search; exit;
$sql = mysqli_query($con, "SELECT * FROM users WHERE bus_cat LIKE '%$search%' OR name LIKE '%$search%' OR bus_name LIKE '%$search%'");

?>

<div class="container">
	<?php 
	while($row = mysqli_fetch_assoc($sql)){  ?>
  <div class="well" style="margin-top: 50px; ">
      <div class="media">
      	<a class="pull-left" href="business_details.php?id=<?php echo $row['id']; ?>">
          <?php $logo = 'uploads/'.$row['logo']; ?>
    		<img class="media-object" src="<?php echo $logo; ?>">
  		</a>
  		<div class="media-body">
    		<h4 class="media-heading"><?php echo $row['bus_name']; ?></h4>
          <p class="text-right"><?php echo $row['email']; ?></p>
          <h4 class="text-right"><?php echo $row['mobile']; ?></h4>
          <p></p>
          <p><?php echo $row['description']; ?></p>
          <!-- <ul class="list-inline list-unstyled">
  			<li><span><i class="glyphicon glyphicon-calendar"></i> 2 days, 8 hours </span></li>
            <li>|</li>
            <span><i class="glyphicon glyphicon-comment"></i> 2 comments</span>
            <li>|</li>
            <li>
               <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star"></span>
                        <span class="glyphicon glyphicon-star-empty"></span>
            </li>
            <li>|</li>
            <li>
             Use Font Awesome http://fortawesome.github.io/Font-Awesome/ -->
              <!-- <span><i class="fa fa-facebook-square"></i></span>
              <span><i class="fa fa-twitter-square"></i></span>
              <span><i class="fa fa-google-plus-square"></i></span>
            </li>
			</ul>  -->
			<p>Category : <?php echo $row['bus_cat']; ?></p>
		</div>
    </div>
  </div>
<?php } ?>
   
</div>
<?php } ?>

<?php include('footer.php'); ?>


