<?php
include('function.php');
$id=$_GET['id'];
if(isset($_GET['id'])){
	//$id = $_GET['id'];
	if(isset($_SESSION['users'])){
		$email = $_SESSION['users'];
		$check = mysqli_query($con, "SELECT * FROM user_fav WHERE bus_id = '$id'");
		//$row = mysqli_fetch_assoc($check);
		if(mysqli_num_rows($check) > 0 ){
			$del = mysqli_query($con, "DELETE FROM user_fav WHERE bus_id = '$id' AND user_email = '$email'");
			echo "<script>alert('--REMOVED FROM FAVOURITE--')</script>";
			echo "<script>window.location.href='index.php'</script>";
		}else{			
			$insert = mysqli_query($con, "INSERT INTO user_fav (bus_id, user_email) VALUES('$id', '$email') ");
			echo "<script>alert('--SUCCESSFULLY ADDED TO FAVOURITE--')</script>";
			echo "<script>window.location.href='business_details.php'</script>";
			//echo "<script>window.location = 'business_details.php'</script>";  
		}
	}else{
		echo "<script>alert('--First Login to add to favourite--')</script>";
		echo "<script>window.location.href='business_details.php'</script>"; 
		// /header('location:business_details.php?id='.$id.'');
	}
}
	

?>